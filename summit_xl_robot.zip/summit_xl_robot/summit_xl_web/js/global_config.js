var hostname = 'Ymir'
var namespace = '/summit_xl_a'
var map_frame = 'summit_xl_a_map'
var map_topic = namespace+'/map'
var has_camera = true