# summit_xl_robot
includes all the packages required for the robot control.

## summit_xl_bringup
This package contains the launch files needed to run the SUMMIT XL robot.

We have to create a file named **robot_params.env**. Besides, we have to include `source ~/robot_params.env` to the *.bashrc* file. This file contains environment variables that establish the actual components of the robot. For example: 
```
export ROBOT_ID=summit_xl
# summit_xl.urdf.xacro
export ROBOT_XACRO=versions/summit_xl_**ID**.urdf.xacro
# true, false
export ROBOT_HAS_FRONT_LASER=false
# sick_tim561, hokuyo_ug01, hokuyo_ust
export ROBOT_FRONT_LASER_MODEL=hokuyo_ust
#export ROBOT_FRONT_LASER_PORT=/dev/ttyACM0
#export ROBOT_FRONT_LASER_IP=192.168.0.10
# true, false
export ROBOT_HAS_REAR_LASER=false
# sick_tim561, hokuyo_ug01, hokuyo_ust
export ROBOT_REAR_LASER_MODEL=hokuyo_ust
#export ROBOT_FRONT_LASER_PORT=/dev/ttyACM1
#export ROBOT_FRONT_LASER_IP=192.168.0.11
# true, false
export ROBOT_HAS_FRONT_PTZ_CAMERA=false
export ROBOT_FRONT_PTZ_CAMERA_IP=192.168.0.185
export ROBOT_FRONT_CAMERA_MODEL=axis_m5013
# true, false
export ROBOT_HAS_REAR_PTZ_CAMERA=false
export ROBOT_REAR_PTZ_CAMERA_IP=192.168.0.186
export ROBOT_REAR_CAMERA_MODEL=axis_m5013
# true, false
export ROBOT_HAS_FRONT_RGBD_CAMERA=false
# usb bus
#export ROBOT_FRONT_RGBD_CAMERA_ID=#1
# true, false
export ROBOT_HAS_REAR_RGBD_CAMERA=false
# usb bus
#export ROBOT_REAR_RGBD_CAMERA_ID=#1
# true, false
export ROBOT_HAS_GPS=false
# ps3, ps4 (default)
export ROBOT_PAD_MODEL=ps4
# 24V motors: 12.52, 48V motors: 9.56
export ROBOT_GEARBOX=9.56
# true, false
export ROBOT_HAS_ENCODER=true
# skid, omni, steel_skid, steel_omni
export ROBOT_KINEMATICS=steel_omni
# true, false
#export ROBOT_HAS_ARM=false
```
##### Explanation of each environment variable
- `ROBOT_ID` indicates the name of the robot. This is the name of the namespace under all the nodes will be working. This is also used as the prefix of all the subcomponents.(*summit_xl*)
- `ROBOT_XACRO` indicates the path where the xacro file is. (inside the robot folder in robot_description)(*summit_xl.urdf.xacro*)
- `ROBOT_FRONT_LASER_MODEL` indicates the model of the laser that the robot is using. The model is the name of the launch file.(*sick_tim561/hokuyo_ug01/hokuyo_ust*)
- `ROBOT_REAR_LASER_MODEL` indicates the model of the laser that the robot is using. The model is the name of the launch file.(*sick_tim561/hokuyo_ug01/hokuyo_ust*)
- `ROBOT_HAS_FRONT_LASER` indicates if the robot has a laser in front. (*true/false*)
- `ROBOT_HAS_REAR_LASER` indicates if the robot has a laser in rear. (*true/false*)
- `ROBOT_HAS_FRONT_PTZ_CAMERA` indicates if the robot has the ptz camera in front. (*true/false*)
- `ROBOT_HAS_REAR_PTZ_CAMERA` indicates if the robot has the ptz camera in front. (*true/false*)
- `ROBOT_HAS_GPS` indicates if the robot has gps. (*true/false*)
- `ROBOT_HAS_FRONT_RGBD_CAMERA` indicates if the robot has a front rgbd camera. (*true/false*)
- `ROBOT_FRONT_RGBD_CAMERA_ID` camera id to identify in the bus
- `ROBOT_HAS_REAR_RGBD_CAMERA` indicates if the robot has a front rgbd camera. (*true/false*)
- `ROBOT_REAR_RGBD_CAMERA_ID` camera id to identify in the bus
- `ROBOT_PAD_MODEL` pad model used. (*ps4/ps3/logitechf710/xbox360*)
- `ROBOT_GEARBOX` establishes the motor gearbox value. (*24V: 12.52 | 48V: 9.56*)
- `ROBOT_HAS_ENCODER` indicates if the robot has encoders. (*true/false*)
- `ROBOT_KINEMATICS` kinematic configuration of the robot. (*skid/omni/steel_skid/steel_omni*)
- `ROBOT_HAS_ARM` indicates if the robot has an arm (*true/false*)
