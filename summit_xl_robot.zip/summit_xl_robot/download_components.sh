#svn co https://free1.projectlocker.com/robotnik/COMPONENTS/svn/usb_cam/ros/fuerte/trunk/usb_cam usb_cam
#svn co https://free1.projectlocker.com/robotnik/COMPONENTS/svn/sphere_camera/ros/fuerte/trunk/sphere_camera sphere_camera
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/axis_camera/ros/groovy/trunk/axis_camera axis_camera
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/fotonic_3dcamera/ros/fuerte/trunk/fotonic_3dcamera fotonic_3dcamera
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/novatel_oemv_gps/ros/fuerte/trunk/novatel_oemv novatel_oemv
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/mediatek_gps/ros/fuerte/trunk/mediatek_gps mediatek_gps
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/robotnik_arduimu/ros/fuerte/trunk/robotnik_arduimu robotnik_arduimu
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/robotnik_gyro/ros/groovy/trunk/robotnik_gyro/
# this version is needed by summit_xl_controller
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/robotnik_msgs/fuerte/robotnik_msgs robotnik_msgs 
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/robotnik_arduimu/ros/groovy/trunk/robotnik_arduimu robotnik_arduimu
#svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/imu_tools/groovy/imu_tools imu_tools
svn co https://venture1.projectlocker.com/robotnik/COMPONENTS/svn/robotnik_tilt_laser/ros/hydro/trunk/robotnik_tilt_laser robotnik_tilt_laser
